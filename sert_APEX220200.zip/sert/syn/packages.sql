set define '^'
set concat off

PROMPT == SV_SEC_ERROR
GRANT EXECUTE on ^esert_user.sv_sec_error to ^parse_as_user
/
CREATE OR REPLACE SYNONYM ^parse_as_user.sv_sec_error FOR ^esert_user.sv_sec_error
/

PROMPT == SV_SEC
GRANT EXECUTE on ^esert_user.sv_sec to ^parse_as_user
/
CREATE OR REPLACE SYNONYM ^parse_as_user.sv_sec FOR ^esert_user.sv_sec
/

PROMPT == SV_SEC_UTIL
GRANT EXECUTE on ^esert_user.sv_sec_util to ^parse_as_user
/
CREATE OR REPLACE SYNONYM ^parse_as_user.sv_sec_util FOR ^esert_user.sv_sec_util
/

PROMPT == SV_SEC_PREF
GRANT EXECUTE on ^esert_user.sv_sec_pref to ^parse_as_user
/
CREATE OR REPLACE SYNONYM ^parse_as_user.sv_sec_pref FOR ^esert_user.sv_sec_pref
/

PROMPT == SV_SEC_HELP
GRANT EXECUTE on ^esert_user.sv_sec_help to ^parse_as_user
/
CREATE OR REPLACE SYNONYM ^parse_as_user.sv_sec_help FOR ^esert_user.sv_sec_help
/

PROMPT == SV_SEC_RULES
GRANT EXECUTE on ^esert_user.sv_sec_rules to ^parse_as_user
/
CREATE OR REPLACE SYNONYM ^parse_as_user.sv_sec_rules FOR ^esert_user.sv_sec_rules
/

PROMPT == SV_SEC_EXPORT
GRANT EXECUTE on ^esert_user.sv_sec_export to ^parse_as_user
/
CREATE OR REPLACE SYNONYM ^parse_as_user.sv_sec_export FOR ^esert_user.sv_sec_export
/

PROMPT == SV_SEC_IMPORT
GRANT EXECUTE on ^esert_user.sv_sec_import to ^parse_as_user
/
CREATE OR REPLACE SYNONYM ^parse_as_user.sv_sec_import FOR ^esert_user.sv_sec_import
/

PROMPT == SV_SEC_LOG_EVENTS
GRANT EXECUTE on ^esert_user.sv_sec_log_events to ^parse_as_user
/
CREATE OR REPLACE SYNONYM ^parse_as_user.sv_sec_log_events FOR ^esert_user.sv_sec_log_events
/

PROMPT == SV_SEC_COLLECTIONS
GRANT EXECUTE on ^esert_user.sv_sec_collections to ^parse_as_user
/
CREATE OR REPLACE SYNONYM ^parse_as_user.sv_sec_collections FOR ^esert_user.sv_sec_collections
/

PROMPT == LOGGER
GRANT EXECUTE on ^esert_user.logger to ^parse_as_user
/
CREATE OR REPLACE SYNONYM ^parse_as_user.logger FOR ^esert_user.logger
/

PROMPT == SV_SEC_FILE_MGR
GRANT EXECUTE on ^esert_user.sv_sec_file_mgr to ^parse_as_user
/
CREATE OR REPLACE SYNONYM ^parse_as_user.sv_sec_file_mgr FOR ^esert_user.sv_sec_file_mgr
/

PROMPT == SV_SEC_SCHEDULER
GRANT EXECUTE on ^esert_user.sv_sec_scheduler to ^parse_as_user
/
CREATE OR REPLACE SYNONYM ^parse_as_user.sv_sec_scheduler FOR ^esert_user.sv_sec_scheduler
/

PROMPT == SV_SEC_EXCEPTION
GRANT EXECUTE on ^esert_user.sv_sec_exception to ^parse_as_user
/
CREATE OR REPLACE SYNONYM ^parse_as_user.sv_sec_exception FOR ^esert_user.sv_sec_exception
/

PROMPT == SV_SEC_ADMIN
GRANT EXECUTE on ^esert_user.sv_sec_admin to ^parse_as_user
/
CREATE OR REPLACE SYNONYM ^parse_as_user.sv_sec_admin FOR ^esert_user.sv_sec_admin
/

PROMPT == SV_SEC_RPT_GENERIC
GRANT EXECUTE on ^esert_user.sv_sec_rpt_generic to ^parse_as_user
/
CREATE OR REPLACE SYNONYM ^parse_as_user.sv_sec_rpt_generic FOR ^esert_user.sv_sec_rpt_generic
/

PROMPT == SV_SEC_RPT_UTIL
GRANT EXECUTE on ^esert_user.sv_sec_rpt_util to ^parse_as_user
/
CREATE OR REPLACE SYNONYM ^parse_as_user.sv_sec_rpt_util FOR ^esert_user.sv_sec_rpt_util
/

PROMPT == SV_SEC_RPT_GENERIC
GRANT EXECUTE on ^esert_user.sv_sec_rpt_generic to ^parse_as_user
/
CREATE OR REPLACE SYNONYM ^parse_as_user.sv_sec_rpt_generic FOR ^esert_user.sv_sec_rpt_generic
/

PROMPT == SV_SEC_RPT_CLASS_SUMMARY
GRANT EXECUTE on ^esert_user.sv_sec_rpt_class_summary to ^parse_as_user
/
CREATE OR REPLACE SYNONYM ^parse_as_user.sv_sec_rpt_class_summary FOR ^esert_user.sv_sec_rpt_class_summary
/

PROMPT == SV_SEC_RPT_MOAR
GRANT EXECUTE on ^esert_user.sv_sec_rpt_moar to ^parse_as_user
/
CREATE OR REPLACE SYNONYM ^parse_as_user.sv_sec_rpt_moar FOR ^esert_user.sv_sec_rpt_moar
/

set concat on

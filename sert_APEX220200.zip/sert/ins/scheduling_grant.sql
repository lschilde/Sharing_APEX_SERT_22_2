set termout on
set define '^'
set concat on
set concat .
set verify off

-- APEX_ADMIN_ROLE GRANTS
GRANT APEX_ADMINISTRATOR_ROLE TO ^esert_user;

PROMPT == SV_SEC_VERSION

CREATE TABLE sv_sec_version
 (
 version                     VARCHAR2(255)        NOT NULL
 )
/
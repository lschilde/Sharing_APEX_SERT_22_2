PROMPT == HTPC
@prc/htpc.pls
/
SHOW ERRORS 
/
